<?php
/*
Plugin Name: Yoast Meta Updater
Description: Import URLs and update Yoast SEO meta fields from a CSV file with options to select which fields to update.
Version: 1.6
Author: Denil Mehta Wordpress Developer
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Add menu item in the admin dashboard
add_action('admin_menu', 'yom_updater_add_admin_menu');

function yom_updater_add_admin_menu() {
    add_menu_page(
        'Yoast Meta Updater',      // Page title
        'Meta Updater',            // Menu title
        'manage_options',          // Capability
        'yoast-meta-updater',      // Menu slug
        'yom_updater_admin_page'   // Callback function
    );
}

// Display the admin page for the plugin
function yom_updater_admin_page() {
    ?>
    <div class="wrap">
        <h1>Yoast Meta Updater</h1>
        <p>Upload a CSV file to update Yoast SEO meta fields for your pages or posts. Select which fields you want to update:</p>
        <form method="post" enctype="multipart/form-data">
            <label for="csv_file">Choose CSV File:</label>
            <input type="file" name="csv_file" id="csv_file" accept=".csv">
            <br><br>
            <input type="checkbox" name="update_meta_title" id="update_meta_title">
            <label for="update_meta_title">Update Meta Title</label>
            <br>
            <input type="checkbox" name="update_meta_description" id="update_meta_description">
            <label for="update_meta_description">Update Meta Description</label>
            <br>
            <input type="checkbox" name="update_og_title" id="update_og_title">
            <label for="update_og_title">Update OG Title</label>
            <br>
            <input type="checkbox" name="update_og_description" id="update_og_description">
            <label for="update_og_description">Update OG Description</label>
            <br><br>
            <?php submit_button('Upload and Update'); ?>
        </form>

        <h2>Download Sample CSV Files</h2>
        <form method="post">
            <input type="checkbox" name="sample_meta_title" id="sample_meta_title">
            <label for="sample_meta_title">Meta Title</label>
            <br>
            <input type="checkbox" name="sample_meta_description" id="sample_meta_description">
            <label for="sample_meta_description">Meta Description</label>
            <br>
            <input type="checkbox" name="sample_og_title" id="sample_og_title">
            <label for="sample_og_title">OG Title</label>
            <br>
            <input type="checkbox" name="sample_og_description" id="sample_og_description">
            <label for="sample_og_description">OG Description</label>
            <br><br>
            <?php submit_button('Generate Sample CSV'); ?>
        </form>
    </div>
    <?php

    // Handle the file upload and update
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['csv_file'])) {
        $update_meta_title = isset($_POST['update_meta_title']) ? true : false;
        $update_meta_description = isset($_POST['update_meta_description']) ? true : false;
        $update_og_title = isset($_POST['update_og_title']) ? true : false;
        $update_og_description = isset($_POST['update_og_description']) ? true : false;

        yom_update_yoast_meta_from_csv($_FILES['csv_file']['tmp_name'], $update_meta_title, $update_meta_description, $update_og_title, $update_og_description);
    }

    // Handle sample CSV generation
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && (!empty($_POST['sample_meta_title']) || !empty($_POST['sample_meta_description']) || !empty($_POST['sample_og_title']) || !empty($_POST['sample_og_description']))) {
        yom_generate_sample_csv();
    }
}

// Generate sample CSV files based on selected options
function yom_generate_sample_csv() {
    $fields = [
        'sample_meta_title' => 'Meta Title',
        'sample_meta_description' => 'Meta Description',
        'sample_og_title' => 'OG Title',
        'sample_og_description' => 'OG Description',
    ];

    $selected_fields = array_filter($fields, function($key) {
        return isset($_POST[$key]) && $_POST[$key] == 'on';
    }, ARRAY_FILTER_USE_KEY);

    if (empty($selected_fields)) {
        echo "<p><em>No fields selected. Please select at least one field to generate the sample CSV.</em></p>";
        return;
    }

    $csv_file_name = 'sample_' . implode('_', array_keys($selected_fields)) . '.csv';
    $csv_content = yom_generate_sample_csv_content(array_values($selected_fields));
    $file_path = plugin_dir_path(__FILE__) . $csv_file_name;
    file_put_contents($file_path, $csv_content);

    echo '<p>Sample CSV generated: <a href="' . plugins_url($csv_file_name, __FILE__) . '" download>Download ' . $csv_file_name . '</a></p>';
}

// Generate sample CSV content based on selected fields
function yom_generate_sample_csv_content($fields) {
    $csv_content = "URL," . implode(",", $fields) . "\n";
    $csv_content .= "http://example.com/post-1," . implode(",", array_fill(0, count($fields), 'Sample')) . "\n";
    $csv_content .= "http://example.com/post-2," . implode(",", array_fill(0, count($fields), 'Sample')) . "\n";
    return $csv_content;
}

// Process the CSV file and update Yoast SEO meta fields based on selected options
function yom_update_yoast_meta_from_csv($csv_file, $update_meta_title, $update_meta_description, $update_og_title, $update_og_description) {
    if (($handle = fopen($csv_file, "r")) !== FALSE) {
        // Skip the header row
        $headers = fgetcsv($handle, 1000, ",");

        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $url = trim($data[0]);
            $meta_title = $update_meta_title ? trim($data[array_search('Meta Title', $headers)]) : '';
            $meta_description = $update_meta_description ? trim($data[array_search('Meta Description', $headers)]) : '';
            $og_title = $update_og_title ? trim($data[array_search('OG Title', $headers)]) : '';
            $og_description = $update_og_description ? trim($data[array_search('OG Description', $headers)]) : '';

            echo "Processing URL: $url<br>";

            // Attempt to get post ID from URL
            $post_id = yom_get_post_id_from_url($url);

            if ($post_id) {
                echo "Found post ID: $post_id<br>";

                // Update Yoast SEO fields based on selected options
                if ($update_meta_title) {
                    $updated_meta_title = update_post_meta($post_id, '_yoast_wpseo_title', $meta_title);
                }

                if ($update_meta_description) {
                    $updated_meta_description = update_post_meta($post_id, '_yoast_wpseo_metadesc', $meta_description);
                }

                if ($update_og_title) {
                    $updated_og_title = update_post_meta($post_id, '_yoast_wpseo_opengraph-title', $og_title);
                }

                if ($update_og_description) {
                    $updated_og_description = update_post_meta($post_id, '_yoast_wpseo_opengraph-description', $og_description);
                }

                echo "<p>Successfully updated post ID $post_id.</p>";
            } else {
                echo "<p>No post found for URL $url.</p>";
            }
        }
        fclose($handle);
    } else {
        echo "<p>Failed to open the CSV file.</p>";
    }
}

// Get post ID from URL
function yom_get_post_id_from_url($url) {
    // First try using url_to_postid
    $post_id = url_to_postid($url);
    if ($post_id) {
        return $post_id;
    }

    // If url_to_postid fails, try using the post slug (post_name)
    $post_name = yom_get_post_slug_from_url($url);
    if ($post_name) {
        global $wpdb;
        $post_id = $wpdb->get_var($wpdb->prepare("
            SELECT ID FROM $wpdb->posts
            WHERE post_name = %s
            AND post_status = 'publish'
        ", $post_name));
    }

    // If still not found, try using the GUID
    if (!$post_id) {
        $post_id = yom_get_post_id_by_guid($url);
    }

    return $post_id;
}

// Extract post slug from URL
function yom_get_post_slug_from_url($url) {
    $parsed_url = wp_parse_url($url);
    if (isset($parsed_url['path'])) {
        $path = trim($parsed_url['path'], '/');
        $path_parts = explode('/', $path);
        $post_slug = end($path_parts); // Get the last part as the post slug
        return $post_slug;
    }
    return false;
}

// Get post ID by GUID
function yom_get_post_id_by_guid($url) {
    global $wpdb;
    $post_id = $wpdb->get_var($wpdb->prepare("
        SELECT ID FROM $wpdb->posts
        WHERE guid = %s
        AND post_status = 'publish'
    ", $url));

    return $post_id;
}
