<?php
/*
Plugin Name: Bulk NoIndex NoFollow Importer
Description: Import URLs and set noindex and nofollow using Yoast SEO from a CSV file.
Version: 1.1
Author: Denil Mehta
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Function to display the plugin settings page
function bulk_noindex_nofollow_importer_settings_page() {
    ?>
    <div class="wrap">
        <h2>Bulk NoIndex NoFollow Importer</h2>
        <p>Upload a CSV file to set NoIndex and NoFollow using Yoast SEO.</p>
        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('bulk_noindex_nofollow_import_action', 'bulk_noindex_nofollow_import_nonce'); ?>
            <label for="csv_file">Upload CSV File:</label>
            <input type="file" name="csv_file" id="csv_file">
            <br><br>
            <input type="submit" name="submit" class="button button-primary" value="Import">
        </form>
        <p><a href="<?php echo plugins_url('demo.csv', __FILE__); ?>" download>Download Sample CSV File</a></p>
    </div>
    <?php
}

// Function to handle form submission and process CSV
function handle_bulk_noindex_nofollow_import() {
    if (isset($_POST['submit'])) {
        // Verify nonce
        if (!isset($_POST['bulk_noindex_nofollow_import_nonce']) || 
            !wp_verify_nonce($_POST['bulk_noindex_nofollow_import_nonce'], 'bulk_noindex_nofollow_import_action')) {
            echo '<div class="error"><p>Nonce verification failed. Please try again.</p></div>';
            return;
        }

        // Check if file is uploaded
        if (!empty($_FILES['csv_file']['tmp_name'])) {
            // Get uploaded file
            $csv_file = $_FILES['csv_file']['tmp_name'];

            // Open and process the CSV file
            if (($handle = fopen($csv_file, 'r')) !== false) {
                // Skip the first line (header)
                fgetcsv($handle);

                // Initialize debug array
                $debug_output = array();

                // Loop through the CSV file and process each row
                while (($data = fgetcsv($handle, 1000, ',')) !== false) {
                    if (count($data) < 3) {
                        $debug_output[] = "Invalid CSV format. Each row must have three columns.";
                        continue;
                    }

                    $url = esc_url_raw($data[0]);
                    $meta_robots_noindex = strtolower(trim($data[1]));
                    $meta_robots_nofollow = strtolower(trim($data[2]));

                    // Convert Meta Robots value to Yoast's noindex and nofollow format
                    $noindex = ($meta_robots_noindex === 'noindex') ? 1 : 0;
                    $nofollow = ($meta_robots_nofollow === 'nofollow') ? 1 : 0;

                    // Get post ID by URL
                    $post_id = url_to_postid($url);

                    if ($post_id) {
                        // Update the noindex and nofollow meta fields used by the Yoast SEO plugin
                        $updated_noindex = update_post_meta($post_id, '_yoast_wpseo_meta-robots-noindex', $noindex);
                        $updated_nofollow = update_post_meta($post_id, '_yoast_wpseo_meta-robots-nofollow', $nofollow);

                        // Add debug info
                        if ($updated_noindex || $updated_nofollow) {
                            $debug_output[] = "Updated post ID {$post_id} - URL: {$url}, NoIndex: {$noindex}, NoFollow: {$nofollow}";
                        } else {
                            $debug_output[] = "Failed to update post ID {$post_id} - URL: {$url}, NoIndex: {$noindex}, NoFollow: {$nofollow}";
                        }
                    } else {
                        // Add debug info for URL not found
                        $debug_output[] = "URL not found in database: {$url}";
                    }
                }

                // Close the CSV file
                fclose($handle);

                // Display debug information
                echo '<div class="updated"><p>CSV file imported successfully!</p>';
                echo '<p><strong>Debug Output:</strong></p>';
                echo '<pre>';
                foreach ($debug_output as $line) {
                    echo esc_html($line) . "\n";
                }
                echo '</pre></div>';
            } else {
                // Error handling for CSV file opening
                echo '<div class="error"><p>Error opening CSV file.</p></div>';
            }
        } else {
            // Error handling for no file uploaded
            echo '<div class="error"><p>Please select a CSV file to import.</p></div>';
        }
    }
}

// Hook into admin_init to handle form submission
add_action('admin_init', 'handle_bulk_noindex_nofollow_import');

// Function to add plugin menu item
function bulk_noindex_nofollow_importer_menu() {
    add_menu_page(
        'Bulk NoIndex NoFollow Importer',
        'Bulk NoIndex NoFollow Importer',
        'manage_options',
        'bulk-noindex-nofollow-importer',
        'bulk_noindex_nofollow_importer_settings_page',
        'dashicons-upload'
    );
}

// Hook into admin_menu to add plugin menu item
add_action('admin_menu', 'bulk_noindex_nofollow_importer_menu');
